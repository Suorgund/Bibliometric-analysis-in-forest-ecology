setwd("D:/R_package/package")
library(openxlsx)
library(tidyverse)
library(stm)
library(stminsights)
library(bibliometrix)
library(splines)
library(readxl)
library(ggplot2)
library(pracma)
library(SnowballC)
library(ggwordcloud)
library(ldatuning)
library(vegan)
library(ggrepel)
library(ggpubr)
library(igraph)
library(quanteda)
library(lda)
library(tidytext)
library(flextable)
library(officer)
library(pheatmap)
library(RColorBrewer)
library(psych)
library(ggbump)
library(ggprism)
library(factoextra)
library(ggalluvial)
library(FactoMineR)
library(ggtree)
library(colourpicker)
####Read csv####
paper_list <- read.xlsx("review_result/all_paper.xlsx")
all_df <- read.xlsx("review_result/all_data_check.xlsx")
stopwords <- readLines("review_result/stop_words_english.txt")
P_join_check <- inner_join(all_df, paper_list, by = c("doi" = "DI"), multiple = "all")
df_package <- P_join_check %>% 
  select(id, year, journal, title, AB, DE, 
         doi, stat, softw_note, package, C1, value) %>% 
  set_names("id", "year", "journal", "title", "abstract", "keywords",
            "doi", "stat", "softw_note", "package", "country", "value")
####STM model####
df_package$year <- as.numeric(df_package$year)
paper_processed <- textProcessor(documents = df_package$abstract,
                                 metadata = df_package,
                                 wordLengths = c(3,Inf),
                                 customstopwords = stopwords,
                                 stem = T)
plotRemoved(paper_processed$documents, lower.thresh = seq(1, 100, by = 1))
paper_out <- prepDocuments(documents = paper_processed$documents,
                           vocab = paper_processed$vocab,
                           meta = paper_processed$meta,
                           lower.thresh = 169,
                           upper.thresh = 14409)
#*fig.s2 topic number----
set.seed(1234)
storge <- searchK(documents = paper_out$documents,
                  vocab = paper_out$vocab,
                  K = c(5:100),
                  prevalence = ~ ns(year), data = paper_out$meta)
pdf("review_result/stm_plot_ntopics.pdf", width = 18, height = 9)
plot(storge)
dev.off()

## 20 topic
poliblogPrevFit_20 <- stm(documents = paper_out$documents,
                          vocab = paper_out$vocab,
                          K = 20,
                          # prevalence = ~ bs(year),
                          data = paper_out$meta,
                          init.type = "LDA",
                          seed = 1234)

papeer_labeltopics_20 <- labelTopics(poliblogPrevFit_20, n = 20, topics = c(1:20))
paper_labeltopics_20 <- as.data.frame(papeer_labeltopics_20$prob)
shortdoc_20 <- substr(paper_out$meta$abstract, 1, nchar(paper_out$meta$abstract))
thoughts_20 <- findThoughts(poliblogPrevFit_20, texts = shortdoc_20, n = 10, topics = c(1:20))
thoughts_20_docs <- as.data.frame(thoughts_20$docs)
thoughts_20_docs <- t(thoughts_20_docs)

topic_term_docs_20 <- cbind(paper_labeltopics_20, thoughts_20_docs)
write.xlsx(topic_term_docs_20, file = "review_result/topic_term_docs_20.xlsx")

#*table.s2 topic table ----
td_beta <- tidy(poliblogPrevFit_20)
td_gamma <- tidy(poliblogPrevFit_20, matrix = "gamma")
top_terms <- td_beta %>%
  arrange(beta) %>%
  group_by(topic) %>%
  top_n(20, beta) %>%
  arrange(-beta) %>%
  select(topic, term) %>%
  summarise(terms = list(term)) %>%
  mutate(terms = map(terms, paste, collapse = ", ")) %>% 
  unnest()
gamma_terms <- td_gamma %>%
  group_by(topic) %>%
  summarise(gamma = mean(gamma)) %>%
  arrange(desc(gamma)) %>%
  left_join(top_terms, by = "topic") %>%
  mutate(topic = paste0("Topic ", topic),
         topic = reorder(topic, gamma))

flex_top <- top_terms %>% 
  mutate(Title = c('Physiological Adaptation', 
                   'Biodiversity & Ecosystem Function',
                   'Climatic Factors','Forest Regeneration', 
                   'Tree Diseases & Pest', 'Tree Genetics',
                   'Ecosystem Carbon Flux', 'Forest Management',
                   'Remote Sensing', 'Forest Alternatives',
                   'Substrate Stoichiometry', 'Canopy Gaps', 'Wildfires',
                   'Habitat Patches', 'Tree Growth', 'Climate Change Modeling', 
                   'Conservation & Sustainability', 'Microclimate',
                   'Land Use Change', 'Urban Green Spaces & Health')) %>%
  arrange(Title) %>% 
  mutate(id = 1:20) %>% 
  select(id, Title, terms) %>% 
  flextable() %>% 
  set_header_labels(values = c("Theme No.", "Title",
                               "Top 20 most frequently used key words")) %>% 
  autofit(add_w = 0.1, add_h = 0.1, part = c("body", "header")) %>% 
  bg(bg = "#FFFFFF", part = "all") %>% 
  width(width = c(0.8, 1.5, 4.2))

save_as_docx(flex_top, path = "review_result/top_20.docx") 
####fig.s3 Topic correlation####
top_cor <- topicCorr(poliblogPrevFit_20, method = "simple")
d_matrix <- as.matrix(top_cor$cor)

rownames(d_matrix)[1:20] <- c('Physiological Adaptation', 
                              'Biodiversity & Ecosystem Function',
                              'Climatic Factors','Forest Regeneration', 
                              'Tree Diseases & Pest', 'Tree Genetics',
                              'Ecosystem Carbon Flux', 'Forest Management',
                              'Remote Sensing', 'Forest Alternatives',
                              'Substrate Stoichiometry', 'Canopy Gaps', 'Wildfires',
                              'Habitat Patches', 'Tree Growth', 'Climate Change Modeling', 
                              'Conservation & Sustainability', 'Microclimate',
                              'Land Use Change', 'Urban Green Spaces & Health')
colnames(d_matrix)[1:20] <- c('Physiological Adaptation', 
                              'Biodiversity & Ecosystem Function',
                              'Climatic Factors','Forest Regeneration', 
                              'Tree Diseases & Pest', 'Tree Genetics',
                              'Ecosystem Carbon Flux', 'Forest Management',
                              'Remote Sensing', 'Forest Alternatives',
                              'Substrate Stoichiometry', 'Canopy Gaps', 'Wildfires',
                              'Habitat Patches', 'Tree Growth', 'Climate Change Modeling', 
                              'Conservation & Sustainability', 'Microclimate',
                              'Land Use Change', 'Urban Green Spaces & Health')
topic_heatmap <- pheatmap(d_matrix, border_color = "grey60", scale = "none",
                          clustering_distance_cols = "correlation", clustering_distance_rows = "correlation", 
                          clustering_method = "ward.D2",
                          cluster_cols = T, cluster_rows = T, 
                          # treeheight_row = 0, 
                          treeheight_col = 0,
                          display_numbers = matrix(ifelse(d_matrix != 0, "***", ""),
                                                   nrow = nrow(d_matrix)),
                          number_format = "%.2f",
                          number_color = "grey30",
                          color = colorRampPalette(c("#B0C4DE", "white", "#EED5D2", "#F08080FF", "#B62300", "grey70"))(100),
                          fontsize = 13,
                          legend_breaks = c(-1, -0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8),
                          show_colnames = F, show_rownames = T,
                          cellwidth = 25, cellheight = 25)
ggsave("review_result/topic_heatmap.pdf", topic_heatmap, width = 11.3, height = 7)
####fig.2 Topic trend####
prep_ns <- estimateEffect(1:20 ~ ns(year),
                          stmobj = poliblogPrevFit_20,
                          metadata = paper_out$meta,
                          uncertainty = "Global")
prep_ns_asdata <- tidy(prep_ns)
prep_ns_data <- prep_ns_asdata[c(2,4,6,8,10,12,14,16,18,20,
                                 22,24,26,28,30,32,34,36,38,40),]
prep_ns_data <- prep_ns_data %>% select(1, 2, 3, 4, 6) %>% 
  set_names("topic_num", "level", "est", "se", "pva") %>% 
  mutate(topic_name = c('Physiological Adaptation', 
                        'Biodiversity & Ecosystem Function',
                        'Climatic Factors','Forest Regeneration', 
                        'Tree Diseases & Pest', 'Tree Genetics',
                        'Ecosystem Carbon Flux', 'Forest Management',
                        'Remote Sensing', 'Forest Alternatives',
                        'Substrate Stoichiometry', 'Canopy Gaps', 'Wildfires',
                        'Habitat Patches', 'Tree Growth', 'Climate Change Modeling', 
                        'Conservation & Sustainability', 'Microclimate',
                        'Land Use Change', 'Urban Green Spaces & Health')) %>% 
  mutate(p_si = case_when(pva < 0.001 ~ paste("***"),
                          pva < 0.01 & pva > 0.001 ~ paste("**"),
                          pva < 0.05 & pva > 0.01 ~ paste("*"))) %>%
  mutate(group = c("Forest monitoring", "Forest management", "Forest monitoring", 
                   "Forest management", "forest damage", "Forest monitoring",
                   "Forest monitoring", "Forest management", "Forest monitoring", 
                   "Forest use", "Forest monitoring", "Forest management", 
                   "Forest management", "Forest management", "forest damage", 
                   "Forest monitoring", "Forest use", "Forest monitoring", 
                   "Forest use", "Forest use"))
prep_factor_group <- prep_ns_data
prep_factor_group$topic_name <- factor(prep_factor_group$topic_name, 
                                       levels = c('Tree Genetics', 'Physiological Adaptation', 
                                                  'Substrate Stoichiometry',
                                                  'Ecosystem Carbon Flux', 'Microclimate', 
                                                  'Remote Sensing', 'Climate Change Modeling', 
                                                  'Climatic Factors', 'Urban Green Spaces & Health', 
                                                  'Forest Alternatives', 'Land Use Change', 
                                                  'Conservation & Sustainability', 'Canopy Gaps', 
                                                  'Forest Management', 'Forest Regeneration',
                                                  'Wildfires', 'Habitat Patches',
                                                  'Biodiversity & Ecosystem Function', 
                                                  'Tree Growth', 'Tree Diseases & Pest'))

topic_trend_2 <- prep_factor_group %>% 
  # mutate(name = fct_reorder(topic_name, est)) %>% 
  ggplot(aes(x = topic_name, y = est
  )) +
  geom_point(size = 7, shape = 21, aes(fill = group)) +
  geom_errorbar(aes(ymin = est - se, 
                    ymax = est + se), 
                width = 0, size = 0.5) +
  geom_text(aes(label = p_si), nudge_y = 0.008, size = 5) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  scale_fill_manual(values = c("#9370DBCC", "#E7B800CC", "#FC4E07CC", "#00AFBBCC")) +
  labs(y = "Topic prevalence change\r\n(2010 to 2022)") +
  coord_flip() +
  theme(panel.grid = element_blank(),
        panel.border = element_rect(color = "black", size = 0.5, fill = NA),
        panel.background = element_blank(),
        axis.title.y = element_blank(),
        # axis.title.x = element_blank(),
        axis.line = element_blank(),
        axis.text.y = element_blank(),
        axis.text.x = element_text(size = 15, colour = "black"),
        plot.margin = margin(rep(.1, 4), unit = "cm"),
        axis.ticks.y = element_blank(),
        legend.position = "none")
topic_hc <- hclust(dist(d_matrix, method = "euclidean"), method = "ward.D2")
plot(topic_hc)
topic_clust <- ggtree(topic_hc, size = 0.8, branch.length = "none", root.position = 0)
topic_clust_rotate <- rotate(topic_clust, 21)
topic_clust_ro <- topic_clust_rotate + 
  geom_strip(6, 3,label = "Forest monitoring", fontsize = 6.5,
             offset = 0, offset.text = 0.33, barsize = 0.6,
             color = "#FC4E07CC", angle = 90, hjust = 0.5) +
  geom_strip(20, 17,label = "Forest use", fontsize = 6.5,
             offset = 0, offset.text = 0.33, barsize = 0.6,
             color = "#00AFBBCC", angle = 90, hjust = 0.5) +
  geom_strip(12, 2,label = "Forest management", fontsize = 6.5,
             offset = 0, offset.text = 0.33, barsize = 0.6,
             color = "#E7B800CC", angle = 90, hjust = 0.5) +
  geom_strip(15, 5,label = "Forest\ndamage", fontsize = 6.5,
             offset = 0, offset.text = 0.83, barsize = 0.6,
             color = "#9370DBCC", angle = 90, hjust = 0.5) +
  # geom_highlight(node = 28, type = "rect", fill = "#9370DBCC") +
  # geom_cladelabel(node = 28, label = "Climate change & forest monitor",
  #                 align = TRUE, offset = -2.1, extend = -1.5) +
  geom_tiplab(size = 7, hjust = 1, offset = 12.9, 
              color = c("#FC4E07CC", "#E7B800CC", "#FC4E07CC", "#E7B800CC",
                        "#9370DBCC", "#FC4E07CC", "#FC4E07CC", "#E7B800CC",
                        "#FC4E07CC", "#00AFBBCC", "#FC4E07CC", "#E7B800CC",
                        "#E7B800CC", "#E7B800CC", "#9370DBCC", "#FC4E07CC", 
                        "#00AFBBCC", "#FC4E07CC", "#00AFBBCC", "#00AFBBCC")) +
  xlim(0, 19) +
  theme_tree() +
  theme(plot.margin = margin(rep(0, 4), unit = "cm"))
clust_cor <- ggarrange(topic_clust_ro, topic_trend_2, align = "h")
ggsave("review_result/clust_cor.pdf", clust_cor, width = 15, height = 9)

####fig.3 Topic alluvium####
paper_dt <- make.dt(poliblogPrevFit_20, meta = paper_out$meta)
paper_dt_topic <- paper_dt %>% mutate(topic_num = apply(paper_dt[, 2:21], 1, function(x){which.max(x)}))
paper_topic <- paper_dt_topic %>% select(c(22:32, 34))
paper_topic$value <- 1
year_topic_sum <- aggregate(data = paper_topic, value ~ year + topic_num, FUN = sum)
year_topic_sum %>% aggregate(value ~ year, FUN = sum)
topic_sum_no22 <- year_topic_sum[-del_22,]

g <- rep(1:80, each = 3)
topic_sum_3 <- tapply(topic_sum_no22$value, g, sum)
topic_sum_3 <- as.data.frame(topic_sum_3)
topic_sum_3[c(4,8,12,16,20,24,28,32,36,40,
              44,48,52,56,60,64,68,72,76,80),] <- c("439", "640", "338", "276",
                                                    "198", "369", "361", "409",
                                                    "391", "57", "452", "85",
                                                    "238", "262", "395", "335",
                                                    "292", "248", "147", "626")
topic_sum_3$year <- c(rep(c("2010-12", "2013-15", "2016-18", "2019-22"), 20))
topic_sum_3$name <- c(rep('Physiological Adaptation', 4), 
                      rep('Biodiversity & Ecosystem Function', 4),
                      rep('Climatic Factors', 4), rep('Forest Regeneration', 4), 
                      rep('Tree Diseases & Pest', 4), rep('Tree Genetics', 4),
                      rep('Ecosystem Carbon Flux', 4), rep('Forest Management', 4),
                      rep('Remote Sensing', 4), rep('Forest Alternatives', 4),
                      rep('Substrate Stoichiometry', 4), rep('Canopy Gaps', 4),
                      rep('Wildfires', 4), rep('Habitat Patches', 4), 
                      rep('Tree Growth', 4), rep('Climate Change Modeling', 4), 
                      rep('Conservation & Sustainability', 4), rep('Microclimate', 4),
                      rep('Land Use Change', 4), rep('Urban Green Spaces & Health', 4))
topic_sum_3$topic_sum_3 <- as.numeric(topic_sum_3$topic_sum_3)
topic_sum_3 %>% filter(year == "2010-12") %>% arrange(topic_sum_3)
topic_sum_3$topic_order <- c("4", "5", "5", "4", 
                             "3", "4", "1", "1",
                             "9", "8", "7", "10", 
                             "12", "14", "16", "13",
                             "14", "12", "15", "17",
                             "6", "11", "12", "8", 
                             "8", "7", "9", "9", 
                             "1", "1", "6", "5",
                             "10", "6", "8", "7", 
                             "20", "20", "20", "20",
                             "5", "2", "2", "3", 
                             "17", "18", "19", "19", 
                             "11", "9", "14", "16",
                             "13", "16", "13", "14", 
                             "2", "3", "4", "6", 
                             "16", "17", "11", "11",
                             "15", "15", "17", "12",
                             "7", "10", "10", "15", 
                             "19", "19", "18", "18", 
                             "18", "13", "3", "2")
topic_sum_3 <- topic_sum_3 %>% set_names("value", "year", "name", "t_order")
topic_sum_3$y_year <- c(rep(c("2010", "2013", "2016", "2019"), 20))
topic_sum_3$y_year <- as.numeric(topic_sum_3$y_year)
# fil_year <- topic_sum_3 %>% filter(y_year == "2010")
# sum(fil_year$value)
topic_sum_3$all <- rep(c("2675", "3344", "4375", "6558"), 20)
topic_sum_3$all <- as.numeric(topic_sum_3$all)
topic_sum_percen <- topic_sum_3 %>% mutate(percen = value/all*100)
topic_sum_percen$t_order <- as.numeric(topic_sum_percen$t_order)
topic_sum_percen$t_order <- factor(topic_sum_percen$t_order, 
                                   levels = c('1', '2', '3', '4',
                                              '5', '6', '7', '8',
                                              '9', '10', '11', '12', 
                                              '13', '14', '15', '16',
                                              '17', '18', '19', '20'))
topic_order_allu <- ggplot(topic_sum_percen, aes(x = year, y = percen, 
                                                 stratum = t_order, 
                                                 alluvium = name,
                                                 fill = name)) +
  geom_alluvium() +
  scale_x_discrete(position = "bottom") +
  labs(x = "Year") +
  scale_fill_manual(values = c("#FFA07A", "#EEDC82", "#D2B48C", "#EEA2AD",
                               "#DDA0DD", "#F5DEB3", "#CD9B9B", "#7B68EE",
                               "#F08080", "#9F79EE", "#B9D3EE", "#CDB5CD",
                               "#5CACEE", "#778899", "#B4EEB4", "#F4A460", 
                               "#A2CD5A", "#FFF68F", "#66CDAA", "#CDC673")) +
  theme(legend.position = "none",
        panel.background = element_blank(),
        panel.border = element_blank(),
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.x = element_blank(),
        plot.margin = margin(rep(0, 4), unit = "cm"),
        axis.title.y = element_blank(),
        axis.text.x.bottom = element_text(size = 13, colour = "black"),
        axis.title.x = element_text(size = 15))
bump_sum <- topic_sum_percen %>% select(1, 3, 4, 5)
bump_all_sum <- aggregate(bump_sum, value ~ name, FUN = sum)
bump_all_sum$t_order <- c('1', '19', '11', '10', '12',
                          '9', '20', '5', '13', '14', 
                          '18', '15', '4', '7', '3',
                          '17', '8', '6','2', '16')
bump_all_sum$t_order <- as.numeric(bump_all_sum$t_order)
bump_bar <- ggplot(bump_all_sum, aes(t_order, value, fill = name)) +
  geom_bar(stat = "identity", position = "stack",
           # width = 0.9, size = 0.25,
           alpha = 0.45) +
  scale_x_reverse() +
  coord_flip() +
  scale_y_continuous(limits = c(0, 1550), breaks = seq(0, 1500, 300),
                     expand = c(0, 0)) +
  scale_fill_manual(values = c("#FFA07A", "#EEDC82", "#D2B48C", "#EEA2AD",
                               "#DDA0DD", "#F5DEB3", "#CD9B9B", "#7B68EE",
                               "#F08080", "#9F79EE", "#B9D3EE", "#CDB5CD",
                               "#5CACEE", "#778899", "#B4EEB4", "#F4A460", 
                               "#A2CD5A", "#FFF68F", "#66CDAA", "#CDC673")) + 
  geom_text(aes(label = name), size = 7, hjust = 1
            # nudge_y = c(-743, -471, -247, -37, -276, -251, 398, -36, -743, -522,
            #             -406, 38, -361, -916, -391, -596, -685, -893, -665, -518)
  ) +
  labs(y = "Number of articles") +
  theme(legend.position = "none",
        panel.background = element_blank(),
        # panel.border = element_rect(color = "black", size = 0.5, fill = NA),
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank(),
        axis.line.x = element_line(colour = "black"),
        # panel.grid = element_line(color = "grey",size = 0.1),
        # axis.ticks.x = element_blank(),
        plot.margin = margin(rep(0, 4), unit = "cm"),
        axis.text.x = element_text(size = 13, colour = "black"),
        axis.title.y = element_blank(), 
        axis.title = element_text(size = 15))
bumpbar_plot <- ggarrange(topic_order_allu, bump_bar, align = "v")
ggsave("review_result/bumpbar_plot.pdf", bumpbar_plot, width = 18, height = 10)

####fig.1 Topic NMDS####
year_topic_dt <- paper_dt %>% select(year, c(2:21))
year_topic_dt <- t(year_topic_dt)
colnames(year_topic_dt) <- year_topic_dt[1,]
year_topic_dt <- year_topic_dt[-1,]
rownames(year_topic_dt)[1:20] <- c('Physiological Adaptation', 
                                   'Biodiversity & Ecosystem Function',
                                   'Climatic Factors','Forest Regeneration', 
                                   'Tree Diseases & Pest', 'Tree Genetics',
                                   'Ecosystem Carbon Flux', 'Forest Management',
                                   'Remote Sensing', 'Forest Alternatives',
                                   'Substrate Stoichiometry', 'Canopy Gaps', 'Wildfires',
                                   'Habitat Patches', 'Tree Growth', 'Climate Change Modeling', 
                                   'Conservation & Sustainability', 'Microclimate',
                                   'Land Use Change', 'Urban Green Spaces & Health')

d <- dist(year_topic_dt, method = "maximum")
fit.average <- hclust(d, method = "complete")

dtnmds <- metaMDS(year_topic_dt, distance = "bray", k = 2)
summary(dtnmds)
dtnmds_stress <- dtnmds$stress
stressplot(dtnmds)

data <- data.frame(dtnmds$points)
data <- cbind(data, topic_sum_est)
data <- data %>%
  mutate(topic_name = rownames(data))
names(data)[1:2] <- c('NMDS1', 'NMDS2')

plot_nmds <- ggplot(data, aes(NMDS1, NMDS2)) +
  geom_point(shape = 21,
             aes(fill = estimate, size = value)) +
  geom_vline(xintercept = 0, lty = 2, size = 0.4) +
  geom_hline(yintercept = 0, lty = 2, size = 0.4) +
  scale_fill_gradient2(limits = c(min(data$estimate), max(data$estimate)),
                       low = "#0099CC",
                       high = "#d06464",
                       midpoint = mean(data$estimate)) +
  scale_size(limits = c(min(data$value), max(data$value)),
             range = c(4,12)) +
  geom_text(aes(label = topic_name), size = 4,
            nudge_x = c(0, 0.445, 0, 0, 0, 0, 0.27, 0.18, 0, 0.18,
                        0, 0, 0, 0, 0.2, 0, 0.2, 0, 0.15, 0),
            nudge_y = c(0.08, 0, 0.07, 0.07, -0.06, 0.08, 0.08, -0.08, 0.07, 0.04,
                        -0.08, -0.06, 0.07, 0.07, 0, -0.07, 0.07, 0.08, 0.06, -0.07)) +
  theme(panel.background = element_blank(),
        panel.border = element_rect(color = "black", size = 0.3, fill = NA),
        plot.margin = margin(rep(0, 4), unit = "cm"),
        axis.text = element_text(size = 11, colour = "black"))
ggsave("review_result/nmds.pdf", plot_nmds, width = 8, height = 7)
####fig.4 Author country####
paper_bA <- biblioAnalysis(P_join_check, sep = ";")
country_inf <- as.data.frame(paper_bA$Countries)
country_inf$Tab <- as.character(country_inf$Tab)
country_inf$Tab <- tolower(country_inf$Tab)
country_inf$Tab <- str_to_title(country_inf$Tab)
country_inf[1,1] <- "USA"
country_inf[7,1] <- "UK"
country_inf[26,1] <- "South Korea"
country_inf[73,1] <- "Republic of Congo"
country_inf[84,1] <- "United Arab Emirates"
world <- map_data("world")
world[, 5] <- str_replace(world[, 5], "Taiwan", "China")
paper_world_map <- world %>% left_join(country_inf, by = c("region" = "Tab"))
author_country <- ggplot(paper_world_map, aes(long, lat, group = group)) +
  geom_polygon(aes(fill = Freq), color = "gray95", linewidth = 0.15) +
  scale_x_continuous(breaks = seq(-180, 210, 45), labels = function(x){paste0(x, "°")}) +
  scale_y_continuous(breaks = seq(-60, 100, 30), labels = function(x){paste0(x, "°")}) +
  scale_fill_gradient(low = "#B9D3EE", high = "#3A5FCD") +
  labs(x = "Longitude", y = "Latitude", fill = "Number of Documents\nabout First Author") +
  theme(panel.background = element_rect(colour = 'gray',
                                        fill = 'transparent'),
        panel.grid = element_line(color = "grey",size = 0.1),
        legend.position = c(0.12, 0.316)
  )
ggsave('review_result/author_country.pdf', author_country, 
       width = 12, height = 7)
####fig.s5 ####
p_country_sel <- df_package %>% select(4, 5)
# p_country_sel$abstract <- str_to_title(p_country_sel$abstract)
p_coun_pas <- paste(p_country_sel$title, p_country_sel$abstract, sep = ". ")
p_coun_pas <- as.data.frame(p_coun_pas)
p_coun_pas$p_coun_pas <- str_to_title(p_coun_pas$p_coun_pas)
world_sel <- world %>% select(5, 6)
world_sel_deldup <- world_sel[!duplicated(world_sel$region),]
world_subsel <- world_sel[!duplicated(world_sel$subregion),]
world_subsel_fil <- world_subsel %>% 
  filter(!subregion %in% c(1:300)) %>% 
  filter(!is.na(subregion))
usa <- c("United States", NA)
world_sel_deldup <- rbind(world_sel_deldup, usa)
uk <- c("United Kingdom", NA)
world_sel_deldup <- rbind(world_sel_deldup, uk)
America <- c("America", NA)
world_sel_deldup <- rbind(world_sel_deldup, America)
Europe <- c("Europe", NA)
world_sel_deldup <- rbind(world_sel_deldup, Europe)
England <- c("England", NA)
world_sel_deldup <- rbind(world_sel_deldup, England)
world_sel_deldup$region <- str_to_title(world_sel_deldup$region)
region_col <- str_c(world_sel_deldup$region, collapse = "|")
inf_detect <- str_extract_all(p_coun_pas$p_coun_pas, region_col)
tit_abs_region <- t(do.call(cbind, lapply(lapply(inf_detect, unlist), 'length<-', max(lengths(inf_detect)))))
all_region <- cbind(p_coun_pas, tit_abs_region)
write.xlsx(all_region, "review_result/p_country_sel.xlsx")
study_site <- read.xlsx("review_result/p_country_sel.xlsx")
p_study_site <- study_site[,-c(1,2)]
paper_study_site <- cbind(df_package, p_study_site)
paper_study_site_nona <- subset(paper_study_site, paper_study_site[, 13] != "NA")
df_sep_site <- c(paper_study_site[, 13])
for (i in 14:187) {
  df_sep_site <- c(df_sep_site, paper_study_site[,i])
}

df_sep_site <- as.data.frame(df_sep_site)
paper_site_nona <- subset(df_sep_site, df_sep_site != "NA")
paper_site_nona$value <- 1
site_sum <- aggregate(paper_site_nona, value ~ df_sep_site, FUN = sum)
sum(site_sum$value)
paper_site_map <- world %>% left_join(site_sum, by = c("region" = "df_sep_site"))
site_map <- ggplot(paper_site_map, aes(long, lat, group = group)) +
  geom_polygon(aes(fill = value), color = "gray95", linewidth = 0.1) +
  scale_x_continuous(breaks = seq(-180, 210, 45), labels = function(x){paste0(x, "°")}) +
  scale_y_continuous(breaks = seq(-60, 100, 30), labels = function(x){paste0(x, "°")}) +
  scale_fill_gradient(low = "#B9D3EE", high = "#3A5FCD") +
  labs(x = "Longitude", y = "Latitude", fill = "Number of Documents\nabout study site") +
  theme(panel.background = element_rect(colour = 'gray',
                                        fill = 'transparent'),
        panel.grid = element_line(color = "grey",size = 0.1),
        legend.position = c(0.12, 0.316)
  )
ggsave('review_result/paper_site_map.pdf', site_map, 
       width = 12, height = 7)

####fig.s4 ####
forest_data <- read.csv("review_result/FAOSTAT_data_en_11-24-2023.csv")
forest_land <- forest_data %>% select(4, 8, 12) %>% 
  filter(Item == "Forest land") %>% set_names("country", "Item", "forest_value")
country_data <- read.csv("review_result/FAOSTAT_data_en_12-14-2023.csv")
country_land <- country_data %>% select(4, 12) %>% 
  set_names("country", "country_value")
forest_country <- forest_land %>% full_join(country_land, by = "country") %>% 
  select(1,3,4)
str(forest_country)
forest_country[8,1] <- "Antigua"
forest_country[nrow(forest_country) + 1,] <- c("Barbuda", "8.12", "44.000")
forest_country[177,1] <- "Saint Barthelemy"
forest_country[25,1] <- "Bolivia"
forest_country[31,1] <- "Brunei"
forest_country[51,1] <- "Ivory Coast"
forest_country[48,1] <- "Republic of Congo"
forest_country[35,1] <- "Cape Verde"
forest_country[54,1] <- "Curacao"
forest_country[56,1] <- "Czech Republic"
forest_country[71,1] <- "Falkland Islands"
forest_country[173,1] <- "Reunion"
forest_country[135,1] <- "Micronesia"
forest_country[222,1] <- "UK"
forest_country[100,1] <- "Iran"
forest_country[42,1] <- "Jersey"
forest_country[nrow(forest_country) + 1,] <- c("Guernsey", "1.02", "19.800")
forest_country[179,1] <- "Nevis"
forest_country[nrow(forest_country) + 1,] <- c("Saint Kitts", "11.00", "26.00")
forest_country[171,1] <- "South Korea"
forest_country[114,1] <- "Laos"
forest_country[181,1] <- "Saint Martin"
forest_country[172,1] <- "Moldova"
forest_country[26,1] <- "Bonaire"
forest_country[nrow(forest_country) + 1,] <- c("Sint Eustatius", "1.91", "32.200")
forest_country[nrow(forest_country) + 1,] <- c("Saba", "1.91", "32.200")
forest_country[146,1] <- "Netherlands"
forest_country[166,1] <- "Pitcairn Islands"
forest_country[57,1] <- "North Korea"
forest_country[nrow(forest_country) + 1,] <- c("Madeira Islands", "3312.00", "9223.000")
forest_country[nrow(forest_country) + 1,] <- c("Azores", "3312.00", "9223.000")
forest_country[175,1] <- "Russia"
forest_country[178,1] <- "Saint Helena"
forest_country[nrow(forest_country) + 1,] <- c("Ascension Island", "2.00", "39.000")
forest_country[69,1] <- "Swaziland"
forest_country[193,1] <- "Sint Maarten"
forest_country[206,1] <- "Syria"
forest_country[213,1] <- "Trinidad"
forest_country[nrow(forest_country) + 1,] <- c("Tobago", "228.19", "513.000")
forest_country[215,1] <- "Turkey"
forest_country[223,1] <- "Tanzania"
forest_country[224,1] <- "USA"
forest_country[183,1] <- "Grenadines"
forest_country[nrow(forest_country) + 1,] <- c("Saint Vincent", "28.54", "39.000")
forest_country[229,1] <- "Venezuela"
forest_country[nrow(forest_country) + 1,] <- c("Virgin Islands", "23.53", "50")
forest_country[230,1] <- "Vietnam"
forest_country[231,1] <- "Wallis and Futuna"
forest_country$forest_value <- as.numeric(forest_country$forest_value)
forest_country$country_value <- as.numeric(forest_country$country_value)
forest_land_world <- world %>% left_join(forest_country, by = c("region" = "country"))
study_site_sum <- site_sum
study_site_sum[158, 1] <- "Republic of Congo"
study_site_sum[51, 1] <- "Democratic Republic of the Congo"
study_site_sum[211, 1] <- "Virgin Islands"
study_site_sum[27, 1] <- "Bosnia and Herzegovina"
study_site_sum[38, 1] <- "Cape Verde"
study_site_sum[39, 1] <- "Central African Republic"
study_site_sum[54, 1] <- "Dominican Republic"
study_site_sum[141, 1] <- "North Macedonia"
study_site_sum[167, 1] <- "Sao Tome and Principe"
study_site_sum[176, 1] <- "Solomon Islands"
study_site_sum[154, 1] <- "French Polynesia"
country_site <- full_join(country_inf, study_site_sum, by = c("Tab" = "df_sep_site"))
options(max.print = 100)
forest_country_per <- forest_country %>% 
  mutate(per = forest_value/country_value*100)
country_site_forest <- country_site %>% 
  full_join(forest_country_per, by = c("Tab" = "country")) %>% 
  set_names("country", "articles", "sites", "forest", "country_area", "f_c_per") %>% 
  filter(!is.na(sites)) %>% filter(!is.na(f_c_per)) %>% 
  mutate(log_fore = log(forest, country_area)) %>% 
  filter(f_c_per != 0)
articles_f_c <- country_site_forest %>% 
  filter(!is.na(articles)) %>% 
  mutate(first_author_per = articles/sum(articles)) %>% 
  mutate(per = first_author_per*100) %>% 
  mutate(log_100_f = log_fore*100)
forest_articles_lm <- list(r2 = format(summary(lm(articles ~ forest, data = articles_f_c))$r.squared, digits = 4),
                           p = format(summary(lm(articles ~ forest, data = articles_f_c))$coefficients[2,4], digits = 4))
forest_articles_eq <- substitute(italic(R)^2~"="~r2~","~italic(P)~"="~p, forest_articles_lm)
forest_articles <- ggplot(articles_f_c, aes(forest, articles)) + 
  geom_point() + 
  geom_smooth(method = "lm", se = F) +
  geom_text_repel(aes(x = forest, y = articles, label = country), 
                  size = 5, color = "black") +
  geom_text(aes(y = 4300,
                x = 700000,
                label = as.character(as.expression(forest_articles_eq))), parse = TRUE) +
  # scale_x_continuous(breaks = seq(0, 1, 0.25), limits = c(0, 1)) +
  labs(x = 'Forest Area (ha)', y = 'Number of Documents about First Author') +
  theme_bw() +
  theme(panel.grid = element_blank(),
        panel.border = element_rect(color = "black", size = 0.5),
        axis.title = element_text(size = 12, colour = "black"),
        axis.text = element_text(size = 12, colour = "black"),
        # axis.line = element_blank(),
        legend.position = c(0.08, 0.8),
        legend.text = element_text(size = 10, colour = "black"),
        legend.title = element_text(size = 12, colour = "black"), 
        plot.margin = margin(rep(0.25, 4), unit = "cm"),
        panel.background = element_blank())
ggsave('review_result/forest_articles.pdf', forest_articles, 
       width = 8, height = 7)

####fig.s6 Software dynamic####
df_soft_sep <- df_package %>% 
  separate(stat, c("stat1", "stat2", "stat3", "stat4"), sep = ",") %>% 
  separate(softw_note, c("softw1", "softw2", "softw3", "softw4", "softw5"), sep = ",")
df_soft_sep <- as.data.frame(df_soft_sep)
df_soft_sep$year <- as.numeric(df_soft_sep$year)
df_sep_year <- rep(df_soft_sep$year, times = 9)
df_sep_year <- as.data.frame(df_sep_year)
df_sep_stat <- c(df_soft_sep[, 8])
for (i in 9:16) {
  df_sep_stat <- c(df_sep_stat, df_soft_sep[,i])
}
df_sep_stat <- as.data.frame(df_sep_stat)
df_sep_sum <- cbind(df_sep_year, df_sep_stat)
df_sep_sum$value <- 1
df_soft_doi <- rep(df_soft_sep$doi, times = 9)
df_soft_doi <- as.data.frame(df_soft_doi)
paper_stat <- cbind(df_sep_sum, df_soft_doi)
df_soft_jour <- rep(df_soft_sep$journal, times = 9)
df_soft_jour <- as.data.frame(df_soft_jour)
paper_stat_jour <- cbind(paper_stat, df_soft_jour)
paper_stat_jour <- paper_stat_jour %>% set_names('year', 'software', 'value', 'doi', 'journal')

paper_stat_nona <- subset(paper_stat_jour, software != "NA")
SOFT_sum <- aggregate(data = paper_stat_nona, value ~ software, FUN = sum)
df_SOFT_sum <- aggregate(data = paper_stat_jour, value ~ year + software, FUN = sum)
df_SOFT_sum <- as.data.frame(df_SOFT_sum)
df_SOFT_sum %>% filter(value >= 20)
SOFT_sum %>% filter(value >= 100)
orderterms <- c("Origin", "Python", "Excel", "Statistica", "JMP", "MATLAB", "SAS", "SPSS", "R")
orderterms <- factor(1:length(orderterms),labels = orderterms)
df_soft_sum_1 <- df_SOFT_sum %>%
  filter(software %in% c("excel", "jmp", "matlab", "r", "origin",
                         "sas", "python", "spss", "statistica")) %>% 
  mutate(soft_name = c(rep("Excel", 13), rep("JMP", 13), rep("MATLAB", 13),
                       rep("Origin", 13), rep("Python", 11), rep("R", 13),
                       rep("SAS", 13), rep("SPSS", 13), rep("Statistica", 13))) %>% 
  arrange(factor(soft_name, levels = levels(orderterms)))
df_soft_sum_1$soft_name <- factor(df_soft_sum_1$soft_name, levels = levels(orderterms))
df_soft_sum_1 %>% aggregate(value ~ software, FUN = sum) %>% 
  mutate(persent = value/16952 * 100)
df_soft_sum_1 %>% aggregate(value ~ software, FUN = sum) %>% 
  filter(software == "r" | software == "sas" | software == "spss") %>% 
  mutate(persent = value/11625 * 100)
soft_segpoint_plot <- ggplot(df_soft_sum_1, aes(x = year, y = value, fill = soft_name)) + 
  geom_bar(stat = "identity", position =  "stack", width = 0.7, size = 0.25) +
  scale_fill_manual(values = c("#ae716ecc", "#EE000099", "#FF7F0099", "#FED43999", "#D5E4A2", 
                               "#96CCCB", "#709AE1DD", "#9EB0FF", "#B883D4CC")) +
  scale_y_continuous(limits = c(0, 2000), breaks = seq(0, 2000, 200),
                     expand = c(0, 0)) +
  scale_x_continuous(limits = c(2009.5, 2022.5), breaks = seq(2010, 2022, 1),
                     expand = c(0, 0)) +
  # geom_text(aes(x = value, y = package,label = pack_name),size = 2) +
  labs(x = 'Year', y = 'Number of statistical software used', fill = 'Software') +
  theme_bw() +
  theme(panel.grid = element_blank(),
        panel.border = element_rect(color = "black", size = 0.5),
        axis.title = element_text(size = 12, colour = "black"),
        axis.text = element_text(size = 12, colour = "black"),
        # axis.line = element_blank(),
        legend.position = c(0.08, 0.8),
        legend.text = element_text(size = 10, colour = "black"),
        legend.title = element_text(size = 12, colour = "black"), 
        plot.margin = margin(rep(0.15, 4), unit = "cm"),
        panel.background = element_blank())
ggsave('review_result/dynamic_plot2.pdf', soft_segpoint_plot, 
       width = 8, height = 7)

####fig.5 Software point line####
python1_2 <- data.frame(year = c("2011", "2012"),
                        software = c("python", "python"),
                        value = c("0", "0"),
                        soft_name = c("Python", "Python"))
soft_data <- rbind(df_soft_sum_1[1:14,], python1_2, df_soft_sum_1[15:nrow(df_soft_sum_1),])
soft_data$soft_num <- c("8", "8", "8", "9", "8", "9", "9", "9", "8", "7", "7", "6", "7",
                        "9", "9", "9", "8", "9", "8", "8", "8", "9", "9", "6", "4", "4",
                        "7", "6", "7", "7", "7", "6", "5", "7", "5", "5", "5", "8", "5",
                        "4", "4", "6", "5", "4", "5", "6", "5", "7", "8", "8", "9", "8",
                        "5", "5", "5", "4", "5", "4", "4", "4", "6", "6", "9", "7", "9",
                        "6", "7", "4", "6", "6", "7", "7", "6", "4", "4", "4", "5", "6",
                        "2", "2", "2", "2", "2", "3", "3", "3", "3", "3", "3", "3", "3",
                        "3", "3", "3", "3", "3", "2", "2", "2", "2", "2", "2", "2", "2",
                        "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1")
soft_data$value <- as.numeric(soft_data$value)
soft_data$soft_num <- as.numeric(soft_data$soft_num)
soft_data$sum <- as.numeric(c(rep(c("410", "455", "544", "690", "675", 
                                    "694", "888", "1018", "1204", "1405", 
                                    "1317", "1857", "468"), 9)))
soft_data_per <- soft_data %>% mutate(percentage = value/sum*100)
ordername <- c("R", "SPSS", "SAS", "Python", "Excel", "MATLAB", "Origin", "Statistica", "JMP")
ordername <- factor(1:length(ordername),labels = ordername)
soft_data_per$soft_name <- factor(soft_data_per$soft_name, levels = levels(ordername))
soft_line <- ggplot(soft_data_per, aes(x = year, y = percentage,
                                       group = soft_name, color = soft_name)) +
  geom_line(linewidth = 1.1) +
  geom_point() +
  scale_color_manual(values = c("#F08080",	"#C2C2C2", "#8FBC8F",	"#CD96CD",
                                "#B0C4DE", "#D8BFD8", "#7AC5CD", "#6CA6CD",
                                "#EEE8AA")) +
  # scale_y_discrete(expand = c(0.01, 0.01)) +
  labs(x = 'Year', y = 'Percentage of statistical software(%)', fill = "Software") +
  theme(panel.background = element_blank(),
        panel.border = element_rect(color = "black", size = 0.5, fill = NA),
        legend.text = element_text(size = 10, colour = "black"),
        legend.title = element_text(size = 12, colour = "black"),
        axis.line = element_line(color = "black", size = 0.3),
        axis.title = element_text(size = 12),
        axis.text = element_text(size = 10))

ggsave("review_result/soft_line.pdf", soft_line, width = 10, height = 7)

####fig.6 package dynamic####
df_pack <- df_package
df_pack[9987, 10] <- "FREddyPro,randomForest,SPEI"
df_pack[4480, 10] <- "randomForest,PMCMR,party"
df_pack[4420, 10] <- "asremlPlus,ordinal"
df_pack[939, 10] <- "Hmisc,xtable,FactoMineR,factoextra,multcomp,ggplot2,tidyverse,leaps,caret,MASS,car"
df_package_sep <- df_pack %>% 
  separate(package, c("pack1", "pack2", "pack3", "pack4", "pack5", "pack6", "pack7", "pack8",
                      "pack9", "pack10", "pack11", "pack12", "pack13", "pack14", "pack15", "pack16",
                      "pack17"), 
           sep = ",")
df_pack_doi <- rep(df_package_sep$doi, times = 17)
df_pack_doi <- as.data.frame(df_pack_doi)
df_pack_rep <- c(df_package_sep[, 10])
for (i in 11:26) {
  df_pack_rep <- c(df_pack_rep, df_package_sep[,i])
}
df_pack_rep <- as.data.frame(df_pack_rep)
df_pack_dr <- cbind(df_pack_rep, df_pack_doi)
df_pack_jour <- rep(df_package_sep$journal, times = 17)
df_pack_jour <- as.data.frame(df_pack_jour)
pack_jour <- cbind(df_pack_dr, df_pack_jour)
pack_jour$value <- 1
pack_jour_fil <- pack_jour %>% set_names('package', 'doi', 'journal', 'value') %>%
  filter(!package %in% c("stats", "base", "factor", "lme", "obitools",
                         "ar", "attach", "bioconductor", "lm", "lmer",
                         "nls", "stat", "statistics"))

pack_jour_fil$package[pack_jour_fil$package == ""] <- NA

df_pack_sum <- aggregate(data = pack_jour_fil, value ~ package, FUN = sum)
sum(df_pack_sum$value)
order_pack <- c('indicspecies', 'spatstat', 'glmmTMB', 'AICcmodavg', 'lavaan', 
                'iNEXT', 'ade4', 'picante', 'lsmeans', 'ape', 
                'FD', 'emmeans', 'randomForest', 'lmerTest', 'dplR', 
                'raster', 'multcomp', 'mgcv', 'MASS', 'car', 
                'ggplot2', 'MuMIn', 'nlme', 'vegan', 'lme4')
order_pack <- factor(1:length(order_pack), labels = order_pack)
df_pack_sum_1 <- df_pack_sum %>% filter(value >= 78) %>% 
  arrange(desc(value)) %>% 
  arrange(factor(package, levels = levels(order_pack)))
df_pack_sum_1$package <- factor(df_pack_sum_1$package, levels = levels(order_pack))
df_pack_sum_1 %>% mutate(paper_use = 5424) %>%
  mutate(per = value/paper_use * 100) %>% round(per, 2)

pack_plot <- ggplot(df_pack_sum_1, aes(x = value, y = package)) + 
  geom_point(aes(color = package), size = 4) +
  geom_segment(aes(x = 0, xend = value, y = package, 
                   yend = package, color = package),
               size = 1.5) +
  # scale_y_continuous(limits = c(0, 1400), breaks = seq(0, 1400, 200),
  #                    expand = c(0, 0)) +
  scale_x_continuous(limits = c(0, 1180), breaks = seq(0, 1100, 200),
                     expand = c(0, 0)) +
  # scale_y_discrete(position = 'right') +
  scale_color_manual(values = c("#a79cd4","#c689d0","#a06fda","#953ada","#895c8b",
                                "#403367","#4f49a3","#466791","#5b83db","#62aad3",
                                "#55baad","#4fbe6c","#84b67c","#a7b43d","#417d61",
                                "#507f2d","#82702d","#bba672","#d49f36","#da8a6d",
                                "#d593a7","#dd6bbb","#bd5975","#dc4555","#df462a")) +
  geom_text(aes(label = value), size = 3.5, hjust = -0.5) +
  labs(x = 'Number of articles', y = 'R packages') +
  theme_bw() +
  theme(panel.grid = element_blank(),
        # axis.title.y = element_blank(),
        axis.text = element_text(color = "black", size = 10),
        axis.ticks = element_blank(),
        legend.position = "none")

ggsave('review_result/pack_plot.pdf', pack_plot,
       width = 9, height = 7)

####table.s5 10 popular packages description####
desc_pack <- c('lme4', 'vegan', 'nlme', 'MuMIn', 'ggplot2', 
               'car', 'MASS', 'mgcv', 'multcomp', 'raster')
desc_pack <- factor(1:length(desc_pack), labels = desc_pack)
pack_description <- df_pack_sum_1 %>% filter(value >= 189) %>% 
  select(1) %>% 
  arrange(factor(package, levels = levels(desc_pack))) %>% 
  mutate(id = 1:n(), .before = 1) %>% 
  mutate(title = c("Linear Mixed-Effects Models using 'Eigen' and S4",
                   "Community Ecology Package", "Linear and Nonlinear Mixed Effects Models",
                   "Multi-Model Inference", "Create Elegant Data Visualisations Using the Grammar of Graphics",
                   "Companion to Applied Regression", "Support Functions and Datasets for Venables and Ripley's MASS",
                   "Mixed GAM Computation Vehicle with Automatic Smoothness Estimation",
                   "Simultaneous Inference in General Parametric Models",
                   "Geographic Data Analysis and Modeling")) %>% 
  mutate(Maintainer = c("Ben Bolker <bbolker+lme4@gmail.com>", "Jari Oksanen <jhoksane@gmail.com>",
                        "R Core Team <R-core@R-project.org>", "Kamil Barton´ <kamil.barton@go2.pl>",
                        "Thomas Lin Pedersen <thomas.pedersen@posit.co>", "John Fox <jfox@mcmaster.ca>",
                        "Brian Ripley <ripley@stats.ox.ac.uk>", "Simon Wood <simon.wood@r-project.org>",
                        "Torsten Hothorn <Torsten.Hothorn@R-project.org>", "Robert J. Hijmans <r.hijmans@gmail.com>")) %>% 
  mutate(Release_date = c("2003-06-25", "2001-09-06", "1999-11-23", "2010-05-28", "2007-06-10",
                          "2001-05-01", "2009-05-08", "2000-10-04", "2002-06-20", "2010-03-20"))


package_information <- pack_description %>% flextable() %>% 
  set_header_labels(values = c("", "Package", "Title", "Maintainer and Email", "Release Date")) %>% 
  autofit(add_w = 0.1, add_h = 0.1, part = c("body", "header")) %>% 
  bg(bg = "#FFFFFF", part = "all") %>%
  width(width = c(0.3, 0.8, 2, 2, 1)) %>% 
  hline_bottom(border = fp_border(color = "black", width = 2), part = "body") %>% 
  hline_top(border = fp_border(color = "black", width = 0.75), part = "body") %>%
  hline_top(border = fp_border(color = "black", width = 2), part = "header") %>% 
  align(align = "center", part = "all") %>% 
  font(fontname = "Times New Roman", part = "all") %>% 
  fontsize(size = 11, part = "all") %>% 
  color(color = "#000000") %>% 
  bold(bold = T, part = "header") 
save_as_docx(path = "review_result/10_package_information.docx", package_information)

####table.s1 journal impact####
df_journal <- df_pack
df_journal[16931, 3] <- "Urban Forestry And Urban Greening"
df_journal[16931, 4] <- "Adults’ motivation for bringing their children to park playgrounds"
df_journal$value[is.na(df_journal$value)] <- 1
# df_journal$journal <- as.factor(df_journal$journal)
df_jour_sum <- aggregate(data = df_journal, value ~ journal, FUN = sum)
order_jour <- c('Nature', 'Science', 'Nature Climate Change',
                'Nature Communications', 'Nature Ecology And Evolution', 'Science Advances',
                'PNAS', 'Ecology Letters', 'Agricultural And Forest Meteorology',
                'Urban Forestry And Urban Greening', 'Tree Physiology',
                'Forest Ecosystems', 'Forest Ecology And Management')
order_jour <- factor(1:length(order_jour), labels = order_jour)
df_jour_impact <- df_jour_sum %>% 
  mutate(impact = c("6.9", "9.8", "3.8", "4.5", "60.9",
                    "31.4", "17.0", "16.9", "12.0", "54.5",
                    "15.4", "4.7", "6.6")) %>% 
  arrange(factor(journal, levels = levels(order_jour))) %>% 
  mutate(id = 1:n(), .before = 1) %>% 
  mutate(JCR_Category = c("Multidisciplinary Sciences", "Multidisciplinary Sciences",
                          "Environment Sciences", "Ecology", "Multidisciplinary Sciences",
                          "Multidisciplinary Sciences", "Multidisciplinary Sciences", 
                          "Ecology", rep("Forestry", 5))) 
total <-  c(NA, "Total", "16952", NA, NA)
df_jour_total <- rbind(df_jour_impact, total)
df_jour_total %>% flextable() %>% 
  set_header_labels(values = c("", "Journal", "Articles", "5-year\nimpact factor\n(2022)", "JCR Category")) %>% 
  autofit(add_w = 0.1, add_h = 0.1, part = c("body", "header")) %>% 
  bg(bg = "#FFFFFF", part = "all") %>%
  width(width = c(1, 2.5, 1, 1.1, 1.5)) %>% 
  hline_bottom(border = fp_border(color = "black", width = 2), part = "body") %>% 
  hline_top(border = fp_border(color = "black", width = 0.75), part = "body") %>%
  hline_top(border = fp_border(color = "black", width = 2), part = "header") %>% 
  align(align = "center", part = "all") %>% 
  font(fontname = "Times New Roman", part = "all") %>% 
  fontsize(size = 11, part = "all") %>% 
  color(color = "#000000") %>% 
  bold(bold = T, part = "header") %>% 
  hline(i = c(13), border = fp_border(color = "black", width = 0.75)) %>% 
  save_as_docx(path = "review_result/journal_impact.docx")

####fig.s7####
df_SOFT_jour <- aggregate(data = paper_stat_jour, value ~ year + journal + software, 
                          FUN = sum)
data_q_1 <- data.frame(year = c(2011, 2012, 2010, 2022, 2010),
                       journal = c('Nature Climate Change', 'Nature Climate Change', 'Nature Communications',
                                   'Science Advances', 'Urban Forestry And Urban Greening'),
                       software = c('r', 'r', 'r', 'r', 'r'),
                       value = c('0', '0', '0', '0', '0'),
                       soft_name = c('R', 'R', 'R', 'R', 'R'))
data_q_1$value <- as.numeric(data_q_1$value)
df_paper_jour <- aggregate(data = df_soft_sep, value ~ year + journal, FUN = sum)
df_paper_jour <- arrange(df_paper_jour, factor(journal, levels = levels(order_jour)))
df_SOFT_jour <- as.data.frame(df_SOFT_jour)
df_soft_jour_1 <- df_SOFT_jour %>%
  filter(software %in% c("r")) %>% 
  mutate(soft_name = c(rep("R", 146))) %>% 
  arrange(factor(journal, levels = levels(order_jour)))
aggregate(data = df_package, value ~ journal, 
          FUN = sum) %>% arrange(value)
df_soft_jour_1 %>% aggregate(value ~ journal, FUN = sum) %>% 
  arrange(by.group = value) %>% 
  mutate(all = as.numeric(c("159", "159", "181", "186", "204", 
                            "349", "467", "526", "924", "1906",
                            "1555", "3165", "7170"))) %>% 
  mutate(per = value/all*100) %>% 
  arrange(by.group = per)
df_soft_jour_1$journal <- factor(df_soft_jour_1$journal, levels = levels(order_jour))
df_soft_jour_2 <- rbind(df_soft_jour_1[1:26,], data_q_1[1:2,],
                        df_soft_jour_1[27:36,], data_q_1[3,],
                        df_soft_jour_1[37:61,], data_q_1[4,],
                        df_soft_jour_1[62:100,], data_q_1[5,], 
                        df_soft_jour_1[101:146,])
jour_soft <- cbind(df_soft_jour_2, df_paper_jour)
options(digits = 3)
df_jour_fil <- jour_soft %>% 
  set_names('year', 'journal', 'software', 'value', 'soft_name', 'date', 'jour', 'articles') %>% 
  select(1:5, 8) %>% 
  mutate(percentage = value/articles*100) %>%
  filter(!year == 2022)

soft_jour_plot <- ggplot(df_jour_fil, aes(x = year, y = percentage)) + 
  geom_point(aes(color = journal, size = value)) +
  geom_smooth(aes(color = journal), method = "lm", se = F, 
              size = 1) +
  scale_color_manual(values = c("#ae716ecc", "#EE000088", "#e7dbca", "#FF7F0099", 
                                "#FED43999", "#96CCCB", "#b8d38f", "#D5E4A2", 
                                "#709AE1aa", "#9EB0FFaa", "#87CEFA99", "#B883D4aa",
                                "#d9b8f199")) +
  scale_x_continuous(limits = c(2009.5, 2021.5), breaks = seq(2010, 2021, 1),
                     expand = c(0, 0)) +
  scale_y_continuous(limits = c(-1, 100.5), breaks = seq(0, 100, 25),
                     expand = c(0, 0)) +
  labs(x = 'Year', y = 'Article use R(%)', color = 'Journal') +
  theme_bw() +
  theme(panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        plot.margin = margin(.1, .1, .1, .1, unit = "cm"),
        legend.text = element_text(size = 12),
        # axis.title.y = element_blank(),
        axis.text.y = element_text(color = "black"),
        axis.text.x = element_text(color = "black"),
        axis.line = element_line(color = "black", size = 0.3)) + 
  guides(size = FALSE)
ggsave("review_result/R_percentage.pdf", soft_jour_plot, width = 9, height = 7)
####fig.s8####
df_jour_soft <- jour_soft %>% 
  set_names('year', 'journal', 'software', 'value', 'soft_name', 'date', 'jour', 'articles') %>% 
  select(1:5, 8) %>% 
  mutate(percentage = value/articles*100)
soft_jour_plot_1 <- ggplot(df_jour_fil, aes(x = journal, y = percentage)) + 
  geom_boxplot() +
  coord_flip() +
  scale_y_continuous(limits = c(-1, 100.5), breaks = seq(0, 100, 25),
                     expand = c(0, 0)) +
  labs(x = 'Journal', y = 'Percentage of articles that use R(%)') +
  theme_bw() +
  theme(panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        legend.position = 'none',
        axis.text.y = element_text(color = "black", size = 13),
        axis.text.x = element_text(color = "black", size = 12),
        axis.title = element_text(size = 14),
        axis.line = element_line(color = "black", size = 0.3))
ggsave("review_result/R_percentage_boxplot.pdf", soft_jour_plot_1,
       width = 9, height = 7)

####table.s6 five popular packages with jornal####
jour_park <- aggregate(data = pack_jour_fil, value ~ journal + package, FUN = sum)
jour_pack <- jour_park %>% arrange(desc(value)) %>% 
  filter(value >= 5) %>% arrange(factor(journal, levels = levels(order_jour)))
jour_pack_5 <- jour_pack[c(1:5, 10:14, 17:26, 50:54, 67:71, 75:79, 105:109, 132:136, 183:187, 204:208, 237:241, 250:254), ]  
jour_pack_5 <- jour_pack_5[,-3]
jp_5 <- jour_pack_5$journal[!duplicated(jour_pack_5$journal)]
jour_dup <- matrix(NA, nrow = length(jp_5), ncol = 2)
for (i in 1:length(jp_5)) {                    
  temp1 <- jour_pack_5[jour_pack_5$journal == jp_5[i],]
  jour_dup[i,1] <- temp1[1,1]
  jour_dup[i,2] <- paste(temp1[,2], collapse = ",")
}
jour_dup <- as.data.frame(jour_dup)
jour13_pack_5 <- jour_dup %>% set_names("jounal", "package") %>% 
  separate(package, c("pack1", "pack2", "pack3", "pack4", "pack5"), sep = ",")
jour13_pack_5 %>% flextable() %>% 
  set_header_labels(values = c("Journal", "Package1", "Package2", "Package3", "Package4", "Package5")) %>% 
  autofit(add_w = 0.1, add_h = 0.1, part = c("body", "header")) %>% 
  bg(bg = "#FFFFFF", part = "all") %>%
  width(width = c(2.5, 0.9, 0.9, 0.9, 0.9, 0.9)) %>% 
  hline_bottom(border = fp_border(color = "black", width = 2), part = "body") %>% 
  hline_top(border = fp_border(color = "black", width = 0.75), part = "body") %>%
  hline_top(border = fp_border(color = "black", width = 2), part = "header") %>% 
  align(align = "center", part = "all") %>% 
  font(fontname = "Times New Roman", part = "all") %>% 
  fontsize(size = 11, part = "all") %>% 
  color(color = "#000000") %>% 
  bold(bold = T, part = "header") %>% 
  save_as_docx(path = "review_result/journal_package.docx")
####table.s7 table of topic, software and package####
ts <- topic_stat_sum %>%
  filter(software %in% c("excel", "jmp", "matlab", "r", "origin",
                         "sas", "python", "spss", "statistica")) %>% 
  arrange(desc(value))
ts[, 1][ts[, 1] == "excel"] <- "Excel"
ts[, 1][ts[, 1] == "jmp"] <- "JMP"
ts[, 1][ts[, 1] == "matlab"] <- "MATLAB"
ts[, 1][ts[, 1] == "origin"] <- "Origin"
ts[, 1][ts[, 1] == "r"] <- "R"
ts[, 1][ts[, 1] == "sas"] <- "SAS"
ts[, 1][ts[, 1] == "python"] <- "Python"
ts[, 1][ts[, 1] == "spss"] <- "SPSS"
ts[, 1][ts[, 1] == "statistica"] <- "Statistica"

ts_all <- ts$topic_num[!duplicated(ts$topic_num)]
ts_dup <- matrix(NA, nrow = length(ts_all), ncol = 2)
for (i in 1:length(ts_all)) {                    
  temp1 <- ts[ts$topic_num == ts_all[i],]
  ts_dup[i,1] <- temp1[1,2]
  ts_dup[i,2] <- paste(temp1[,1], collapse = ", ")
}
ts_dup <- as.data.frame(ts_dup)

tp <- topic_pack_sum_1 %>% arrange(desc(value))
tp_all <- tp$topic_num[!duplicated(tp$topic_num)]
tp_dup <- matrix(NA, nrow = length(tp_all), ncol = 2)
for (i in 1:length(tp_all)) {                    
  temp1 <- tp[tp$topic_num == tp_all[i],]
  tp_dup[i,1] <- temp1[1,2]
  tp_dup[i,2] <- paste(temp1[,1], collapse = ", ")
}
tp_dup <- as.data.frame(tp_dup)
paper_topic %>% filter(!is.na(package)) %>% aggregate(value ~ topic_num, FUN = sum)

topic_soft_pack <- full_join(ts_dup, tp_dup, by = "V1")
t_soft_pack <- topic_soft_pack %>% 
  set_names("topic_num", "Software", "Package") %>% 
  arrange(as.numeric(topic_num)) %>% 
  mutate(name = c('Physiological Adaptation', 
                  'Biodiversity & Ecosystem Function',
                  'Climatic Factors','Forest Regeneration', 
                  'Tree Diseases & Pest', 'Tree Genetics',
                  'Ecosystem Carbon Flux', 'Forest Management',
                  'Remote Sensing', 'Forest Alternatives',
                  'Substrate Stoichiometry', 'Canopy Gaps', 'Wildfires',
                  'Habitat Patches', 'Tree Growth', 'Climate Change Modeling', 
                  'Conservation & Sustainability', 'Microclimate',
                  'Land Use Change', 'Urban Green Spaces & Health')) %>% 
  arrange(name) %>% 
  select(name, Software, Package)

t_soft_pack %>% flextable() %>% 
  set_header_labels(values = c("Topic", "Software", "Package")) %>% 
  autofit(add_w = 0.1, add_h = 0.1, part = c("body", "header")) %>% 
  bg(bg = "#FFFFFF", part = "all") %>%
  width(width = c(1, 1, 5)) %>% 
  hline_bottom(border = fp_border(color = "black", width = 2), part = "body") %>% 
  hline_top(border = fp_border(color = "black", width = 0.75), part = "body") %>%
  hline_top(border = fp_border(color = "black", width = 2), part = "header") %>% 
  align(align = "center", part = "all") %>% 
  font(fontname = "Times New Roman", part = "all") %>% 
  fontsize(size = 11, part = "all") %>% 
  color(color = "#000000") %>% 
  bold(bold = T, part = "header") %>% 
  save_as_docx(path = "review_result/tsp_table.docx")
####table.1 ####
tp_max <- tp %>% filter(value >= 3) %>% 
  arrange(topic_num)
tp_max_5 <- tp_max[c(1:5, 41:45, 193:197, 225:229, 274:278, 313:317, 357:361, 
                     383:387, 451:455, 497:506, 537:541, 554:558, 596:600,
                     667:671, 737:741, 802:806, 841:845, 855:859, 881:885),]
tp_max_all <- tp_max_5$topic_num[!duplicated(tp_max_5$topic_num)]
tp_max_dup <- matrix(NA, nrow = length(tp_max_all), ncol = 2)
for (i in 1:length(tp_max_all)) {                    
  temp1 <- tp_max_5[tp_max_5$topic_num == tp_max_all[i],]
  tp_max_dup[i,1] <- temp1[1,2]
  tp_max_dup[i,2] <- paste(temp1[,1], collapse = ", ")
}
tp_max_dup <- as.data.frame(tp_max_dup)
topic_pack_5 <- tp_max_dup %>% set_names("topic", "package") %>% 
  separate(package, c("pack1", "pack2", "pack3", "pack4", "pack5"), sep = ", ") %>% 
  mutate(name = c('Physiological Adaptation', 
                  'Biodiversity & Ecosystem Function',
                  'Climatic Factors','Forest Regeneration', 
                  'Tree Diseases & Pest', 'Tree Genetics',
                  'Ecosystem Carbon Flux', 'Forest Management',
                  'Remote Sensing', 'Forest Alternatives',
                  'Substrate Stoichiometry', 'Canopy Gaps', 'Wildfires',
                  'Habitat Patches', 'Tree Growth', 'Climate Change Modeling', 
                  'Conservation & Sustainability', 'Microclimate',
                  'Land Use Change', 'Urban Green Spaces & Health')) %>% 
  arrange(name) %>% 
  mutate(id = 1:20) %>%
  select(id, 7, 2, 3, 4, 5, 6)

topic_pack_5 %>% flextable() %>% 
  set_header_labels(values = c("No.", "Title", "Package1", "Package2", "Package3", "Package4", "Package5")) %>% 
  autofit(add_w = 0.1, add_h = 0.1, part = c("body", "header")) %>% 
  bg(bg = "#FFFFFF", part = "all") %>%
  width(width = c(0.6, 1.5, 1, 0.9, 0.9, 0.9, 0.9)) %>% 
  hline_bottom(border = fp_border(color = "black", width = 2), part = "body") %>% 
  hline_top(border = fp_border(color = "black", width = 0.75), part = "body") %>%
  hline_top(border = fp_border(color = "black", width = 2), part = "header") %>% 
  align(align = "center", part = "all") %>% 
  font(fontname = "Times New Roman", part = "all") %>% 
  fontsize(size = 11, part = "all") %>% 
  color(color = "#000000") %>% 
  bold(bold = T, part = "header") %>% 
  save_as_docx(path = "review_result/topic_package.docx")

####FIG.S9 percentage of articles with topic####
ts_sum <- topic_stat_sum
ts_sum_fil <- ts_sum %>% filter(software %in% c("excel", "jmp", "matlab", "r", "origin",
                                                "sas", "python", "spss", "statistica"))
ts_sum_fil[, 1][ts_sum_fil[, 1] == "excel"] <- "Excel"
ts_sum_fil[, 1][ts_sum_fil[, 1] == "jmp"] <- "JMP"
ts_sum_fil[, 1][ts_sum_fil[, 1] == "matlab"] <- "MATLAB"
ts_sum_fil[, 1][ts_sum_fil[, 1] == "origin"] <- "Origin"
ts_sum_fil[, 1][ts_sum_fil[, 1] == "r"] <- "R"
ts_sum_fil[, 1][ts_sum_fil[, 1] == "sas"] <- "SAS"
ts_sum_fil[, 1][ts_sum_fil[, 1] == "python"] <- "Python"
ts_sum_fil[, 1][ts_sum_fil[, 1] == "spss"] <- "SPSS"
ts_sum_fil[, 1][ts_sum_fil[, 1] == "statistica"] <- "Statistica"
ts_sum_fil$software <- factor(ts_sum_fil$software, levels = levels(ordername))
tp_sum <- topic_pack_sum_1

topic_1 <- ts_sum_fil %>% filter(topic_num == c("1"))
topic_1_plot <- ggplot(topic_1, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Physiological Adaptation") +
  theme(legend.position = "none",
        panel.grid = element_blank(),
        panel.border = element_blank(),
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_2 <- ts_sum_fil %>% filter(topic_num == c("2"))
topic_2_plot <- ggplot(topic_2, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Biodiversity & Ecosystem Function") +
  theme(legend.position = "none",
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_3 <- ts_sum_fil %>% filter(topic_num == c("3"))
topic_3_plot <- ggplot(topic_3, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Climatic Factors") +
  theme(legend.position = "none",
        panel.grid = element_blank(),
        panel.border = element_blank(),
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_4 <- ts_sum_fil %>% filter(topic_num == c("4"))
topic_4_plot <- ggplot(topic_4, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	
                               "#668B8B", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Forest Regeneration") +
  theme(legend.position = "none",
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_5 <- ts_sum_fil %>% filter(topic_num == c("5"))
topic_5_plot <- ggplot(topic_5, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Tree Diseases & Pest") +
  theme(legend.position = "none",
        panel.grid = element_blank(),
        panel.border = element_blank(),
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_6 <- ts_sum_fil %>% filter(topic_num == c("6"))
topic_6_plot <- ggplot(topic_6, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Tree Genetics") +
  theme(legend.position = "none",
        panel.grid = element_blank(),
        panel.border = element_blank(),
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_7 <- ts_sum_fil %>% filter(topic_num == c("7"))
topic_7_plot <- ggplot(topic_7, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Ecosystem Carbon Flux") +
  theme(legend.position = "none",
        panel.grid = element_blank(),
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_8 <- ts_sum_fil %>% filter(topic_num == c("8"))
topic_8_plot <- ggplot(topic_8, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Forest Management") +
  theme(legend.position = "none",
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_9 <- ts_sum_fil %>% filter(topic_num == c("9"))
topic_9_plot <- ggplot(topic_9, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Remote Sensing") +
  theme(legend.position = "none",
        panel.grid = element_blank(),
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_10 <- ts_sum_fil %>% filter(topic_num == c("10"))
topic_10_plot <- ggplot(topic_10, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Forest Alternatives") +
  theme(legend.position = "none",
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_11 <- ts_sum_fil %>% filter(topic_num == c("11"))
topic_11_plot <- ggplot(topic_11, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Substrate Stoichiometry") +
  theme(legend.position = "none",
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_12 <- ts_sum_fil %>% filter(topic_num == c("12"))
topic_12_plot <- ggplot(topic_12, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Canopy Gaps") +
  theme(legend.position = "none",
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_13 <- ts_sum_fil %>% filter(topic_num == c("13"))
topic_13_plot <- ggplot(topic_13, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Wildfires") +
  theme(legend.position = "none",
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_14 <- ts_sum_fil %>% filter(topic_num == c("14"))
topic_14_plot <- ggplot(topic_14, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Habitat Patches") +
  theme(legend.position = "none",
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_15 <- ts_sum_fil %>% filter(topic_num == c("15"))
topic_15_plot <- ggplot(topic_15, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Tree Growth") +
  theme(legend.position = "none",
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_16 <- ts_sum_fil %>% filter(topic_num == c("16"))
topic_16_plot <- ggplot(topic_16, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Climate Change Modeling") +
  theme(legend.position = "none",
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_17 <- ts_sum_fil %>% filter(topic_num == c("17"))
topic_17_plot <- ggplot(topic_17, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Conservation & Sustainability") +
  theme(legend.position = "none",
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_18 <- ts_sum_fil %>% filter(topic_num == c("18"))
topic_18_plot <- ggplot(topic_18, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Microclimate") +
  theme(legend.position = "none",
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_19 <- ts_sum_fil %>% filter(topic_num == c("19"))
topic_19_plot <- ggplot(topic_19, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Land Use Change") +
  theme(legend.position = "none",
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_20 <- ts_sum_fil %>% filter(topic_num == c("20"))
topic_20_plot <- ggplot(topic_20, aes(x = "", y = value, fill = software)) + 
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  scale_fill_manual(values = c("#3B49927F",	"#EE00007F", "#008B457F",	"#EECFA1",
                               "#668B8B", "#BC8F8F", "#6CA6CD", "#A200567F",
                               "#8081807F")) +
  labs(title = "Urban Green Spaces & Health") +
  theme(legend.position = "none",
        legend.text = element_text(size = 12, colour = "black"),
        legend.title = element_text(size = 14, colour = "black"),
        panel.grid = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        plot.margin = margin(rep(0,4), unit = 'cm'),
        plot.title = element_text(hjust = 0.5, size = 20),
        axis.ticks = element_blank())

topic_soft_arrange <- ggarrange(topic_2_plot, topic_12_plot, topic_16_plot, topic_3_plot, 
                                topic_17_plot, topic_7_plot, topic_10_plot, topic_8_plot,
                                topic_4_plot, topic_14_plot, topic_19_plot, topic_18_plot, 
                                topic_1_plot, topic_9_plot, topic_11_plot, topic_5_plot,
                                topic_6_plot, topic_15_plot, topic_20_plot,
                                topic_13_plot, ncol = 4, nrow = 5,
                                common.legend = T, legend = "right")
ggsave("review_result/topic_soft_arrange.pdf", topic_soft_arrange, width = 17.7, height = 18)








